package service;

import model.User;
import model.Role;

import java.util.HashMap;
import java.util.Map;

public class UserService {
    private static Map<String, User> users = new HashMap<>();

    static {
        users.put("admin@example.com", new User("admin@example.com", "admin123", Role.ADMIN));
        users.put("user@example.com", new User("user@example.com", "user123", Role.ORDINARY));
    }

    public static User authenticate(String email, String password) {
        User user = users.get(email);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
}