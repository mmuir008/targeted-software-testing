package model;

public class User {
    private String emailAddress;
    private String password;
    private Role role;

    public User(String emailAddress, String password, Role role) {
        this.emailAddress = emailAddress;
        this.password = password;
        this.role = role;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getPassword() {
        return password;
    }

    public Role getRole() {
        return role;
    }
}