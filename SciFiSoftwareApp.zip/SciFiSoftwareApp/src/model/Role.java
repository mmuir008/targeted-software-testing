package model;

public enum Role {
    ORDINARY,
    ADMIN;
}