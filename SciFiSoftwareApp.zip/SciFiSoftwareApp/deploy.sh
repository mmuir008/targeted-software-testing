
rm -rf build

mkdir -p build/WEB-INF/classes

javac -cp "/Users/maxmuir/Apps/apache-tomcat-9.0.105/lib/servlet-api.jar" -d build/WEB-INF/classes -sourcepath src $(find src -name "*.java")

cp -r webapp/* build/

cd build
jar -cvf SciFiSoftwareApp.war *

cp SciFiSoftwareApp.war ../../apache-tomcat-9.0.105/webapps